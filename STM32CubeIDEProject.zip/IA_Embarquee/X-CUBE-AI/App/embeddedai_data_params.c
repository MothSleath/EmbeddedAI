/**
  ******************************************************************************
  * @file    embeddedai_data_params.c
  * @author  AST Embedded Analytics Research Platform
  * @date    2025-03-22T16:47:31+0100
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */

#include "embeddedai_data_params.h"


/**  Activations Section  ****************************************************/
ai_handle g_embeddedai_activations_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(NULL),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};




/**  Weights Section  ********************************************************/
AI_ALIGNED(32)
const ai_u64 s_embeddedai_weights_array_u64[547] = {
  0xbe8dbb513cb5b046U, 0xbf7906843eac8e08U, 0xbe4fa99d3dd0ac55U, 0x3e200cb83e4aaa83U,
  0xbc4c693ebea79868U, 0xbe439c28bec0605dU, 0xbe8bdd813ea047acU, 0x3ec90b4e3df32449U,
  0xbe45e47fbe916414U, 0xbccd3700be429fa6U, 0x3e7ea7bd3e5af188U, 0x3d8c6d923e5f28e2U,
  0x3eca4e44beabf698U, 0xbe7184ac3c247800U, 0xbd3638f03ea10d80U, 0x3ec8c8c2be8bcddaU,
  0xbd392e80bd9b62b0U, 0x3e7f4458be468e2eU, 0xbe48fb083e7885acU, 0x3e44a934bec4d0eaU,
  0xbe8170be3e37c0bcU, 0x3daa7ac8bebe543eU, 0xbcb7ebc03e6b8780U, 0xbe8879903e93295cU,
  0xbdb49b443e2d3f2cU, 0xbe99a3d03e50fd7bU, 0x3db52b0fbc83a96bU, 0x3e0c9b343ef4e12eU,
  0xbeca13bf3e4713c4U, 0x3c0df8c0be0e41d4U, 0x3cdb10ea3e464c69U, 0x3ebc4d503e95f35cU,
  0x3dfcc2e63ec45fe9U, 0x3e8b24d6beb69b50U, 0xbe0706b8bd5f3435U, 0xbea4aca6bc9e7de0U,
  0xbf420cb33e649afeU, 0x3cbd2181bd6655cbU, 0xbcc750d93ea60965U, 0xbe2ba108bf17e2e0U,
  0xbd1ccc303eaf126aU, 0xbc2da160bec25d51U, 0x3e87ba4abe847eccU, 0x3e72d3fc3ec9e0f9U,
  0x3cffe625be1831e3U, 0x3e7139f8bdeec173U, 0xbf899a003da2c951U, 0xbed757943e1c531eU,
  0x3e98180dbeb27160U, 0x3ea1b8bf3f5eabe4U, 0xbea0055a3e2e72e9U, 0x3669c7203e8adb38U,
  0xbe53aecf3d73a2e0U, 0xbc9355b0bd874938U, 0x3e85797cbe54109dU, 0x3eb1a1013e89e798U,
  0xbee5d251be5638c7U, 0x3ad833743f1b192fU, 0x3eaa56ffbe518ac9U, 0xbde7e4d4bd6cfecfU,
  0x3e090da53dadc2dbU, 0xbde1d7523eaeb5acU, 0xbe776435bec11547U, 0xbece0a4c3daca1ecU,
  0x3eadaa0e3e8c6e06U, 0x3cdd2579beb36a7aU, 0x3f2593653dc73254U, 0xbdbee354be8ab0efU,
  0xbe658dbc3e68ebb4U, 0x3e7204a8be1971a8U, 0x3eb90e9cbeb4d42dU, 0x3ed389ee3d6961d6U,
  0x3daf46a3be842833U, 0x3e72f0323e787b77U, 0x3e43bd253ebb8209U, 0x3e0c7e05be91e93fU,
  0xbefb5c363e601a4fU, 0xbe95b5e33ec39fe2U, 0x3dbe570cbdf303eeU, 0x3e6508073f5dd785U,
  0xbb566fe9bd435a1bU, 0xbc72de60U, 0xbd85085fU, 0x0U,
  0x0U, 0xbbd97baaU, 0xbd4037aabd0e0da2U, 0xbd1f5c79bda39fbfU,
  0x3dfc8b6300000000U, 0xbc9a67f5bda08824U, 0xbe165589U, 0xbd7a0b3abd1e1937U,
  0xbc84266aU, 0xbd36b856U, 0x3b744abfbb7b3570U, 0x3c610b79be03d8a3U,
  0xbeaaf890be17702bU, 0x3e56ebeabe70ee64U, 0x3eb1ae8d3e9988efU, 0xbe9d7c803d83eb34U,
  0x3eb262cdbd8ac208U, 0x3df41618bd412ac7U, 0xbe949dd13e967f92U, 0xbe8567e4bc2b4e07U,
  0xbdf98b5fbe3169c7U, 0x3e569642be030196U, 0xbea654cc3e84f3b3U, 0x3d0bcb943f782407U,
  0xbe9697b1be4bc5b8U, 0xbe26e7b93e99195bU, 0x3c1892943e6ad2b8U, 0x3e7c8afebc9076c5U,
  0x3e6492823e9f7d74U, 0xbe86cbf3be843474U, 0x3da067303ea488deU, 0x3dd08c28be5b29ceU,
  0x3e309f5a3e1997f6U, 0xbeb4e5d9be6c6698U, 0x3d032999be1323f3U, 0xbe09f13cbc933c32U,
  0xbdae63a83e544d32U, 0xbeb84c7bbe8b7ea8U, 0xbe94a7eabe22b4c0U, 0x3cc46457be8a5222U,
  0xbeaf5fb6bdc94fe9U, 0x3e36b42ebe3ba8f8U, 0x3d538d0a3e2a6a6bU, 0x3e8cb4063d7c3b37U,
  0x3e9df8653e096d64U, 0x3b0477803e58b482U, 0x3e994983bd8232a0U, 0x3dfc9988bea07cc2U,
  0xbea3ad263e35cabeU, 0x3d9dcbc43e7c056aU, 0xbeaf19bbbe6e87d7U, 0xbe7e829c3ea8cc01U,
  0x3e50d56e3e899cd3U, 0xbe552abe3e873839U, 0xb9e74400be2f81c9U, 0xbe1269fcbc032ac0U,
  0xbe978e243cd6df10U, 0xbe52770abe2eb94cU, 0xbea249983e78bd5aU, 0x3d866a78be507c00U,
  0xbe7354483e7979aaU, 0xbe635e7d3e83849dU, 0xbeaabb65be27040dU, 0xbe5e60153e1a72a6U,
  0x3d6b82d8bdfa5bacU, 0x3eb2c243bdfceb78U, 0x3dfa2354be6a3652U, 0xbbe21f40be93f8dcU,
  0x3e942fc7be978a8aU, 0xbe60e89cbe2493a2U, 0xbe6cb0993ea74825U, 0xbe0ecf63bc7af000U,
  0x3e05f258be880abeU, 0x3e088cc03d123230U, 0x3d45ace83e950a7dU, 0x3e9ee679bdac4d68U,
  0xbeb1b53abbcdcb00U, 0xbd4534103ea455a3U, 0x3e1f5e723ea77ebfU, 0x3ea6a157be32c87bU,
  0x3e53b1e23e036834U, 0xbeb12a07be00a0baU, 0xbbbbe000be724713U, 0x3db5d45039c12c00U,
  0xbdec6d78bea5c763U, 0xbdb5db103ea0e1b1U, 0x3e818c1dbeb0e26cU, 0xbdd1fd38be24e56fU,
  0xbc9133003e28fbf2U, 0x3e8e7b51beaa0ba6U, 0xbe0d4c833e556eceU, 0xbe20c6d43e1a8db6U,
  0xbe9c5d0cbea6f717U, 0x3dd827b43eae7089U, 0x3e576d4a3eacf4fbU, 0x3e6365eabe4a2b33U,
  0xbd9b4088bd855634U, 0xbe928d353dccc8dcU, 0xbe50e342be06c500U, 0xbe5587c63eada1d7U,
  0xbe2fc9c73e73339aU, 0xbb5fc400be7a9c76U, 0x3e9059c9bcced590U, 0x3d8737943dc222bcU,
  0x3ea77b95be126fe8U, 0x3db7c818bde78966U, 0x3e672ea23e218582U, 0xbe82b092be8d1c13U,
  0x3e389453be3e871eU, 0x3ea0fe9fbe8452a2U, 0xbea14fa73e180835U, 0xbdb6b0a8be8c55aaU,
  0x3e3b5b363e9748e9U, 0x3d0d0f683e565ef3U, 0xbe38711cbe0f3027U, 0x3d0987dfbd057fc5U,
  0x3e6c9bb63e935b3dU, 0xbd4e2e7b3dade5acU, 0x3e9d58893e008cdbU, 0xbdd43afdbdf198fcU,
  0x3e411dd6bd02fdb2U, 0x3e9d17e9bd2b86baU, 0x3e3d44d83daf668eU, 0x3e988e6d3e11079cU,
  0x3d3c1be8be9c8190U, 0xbea4f5c13ddddfdcU, 0xbcdc4270bdb1bd00U, 0x3dea118cbcfb8330U,
  0x3e4bd62abd212648U, 0x3e4e250a3cd31870U, 0xbdd0ee0cbe3224a1U, 0x3d840aa0be1bfb50U,
  0x3e88f30d3e491822U, 0x3e4f80563c21c1a0U, 0x3d857afc3e931fffU, 0xbe950abe3e349622U,
  0x3e6563eabdb67ad4U, 0x3e3aa85abe53da35U, 0xbe96d733bea1b09bU, 0x3e7f856ebe9f7ba9U,
  0xbe506b573e3e2db7U, 0xbe02261fbece4b98U, 0xbdbb7f403e975096U, 0x3e4f3b2a3ea5b103U,
  0xbd769cb03d8e92b0U, 0xbe2452c1be9c1f6cU, 0xbec0c6da3e857a5bU, 0x3e28d3663dd79088U,
  0x3e25f811be6d1b5fU, 0xbeed4bfc3e61374cU, 0xbea882d73d83f86bU, 0x3d4968d73f95bf3eU,
  0xbe6012343dbc7a00U, 0x3d27ac50be6fc4ceU, 0xbdd7484ebc0feae2U, 0xbd320e45be651d6fU,
  0xbe5d9a77be3fe821U, 0xbe82a6c5bebcdde8U, 0x3e1f69ea3e8a5087U, 0xbeacf838beaae99dU,
  0xbeb445563e8d56c1U, 0xbe4e47d7bef73b7aU, 0x3ea988dfbd21474dU, 0x3ccf78563e1a4227U,
  0xbd94a4ce3cb56c00U, 0x3df9dacdbe4a9f3eU, 0xbe9dfb203ddc337bU, 0x3ea29fcdbfbd0725U,
  0xbea52def3e96949dU, 0x3e0d7e2a3ea43922U, 0xbe1af0ba3e3d9caeU, 0xbdf35d04bec20dd8U,
  0x3e5429e73e695056U, 0xbe856d91be565c8aU, 0xbd1670a8be994aecU, 0x3dd1b934be880c06U,
  0xbe70ee4bbe7d55abU, 0x3e3d03de3f1eedb7U, 0x3e9346f3bd8abf0dU, 0x3e3b13d73e043b91U,
  0x3d5a5256be86a8eaU, 0xbe73efdf3e5d6653U, 0x3df3cdd83dd6557bU, 0xbe73d12cbfa024faU,
  0xbe7d9532beac2129U, 0xbdee688cbe3d35feU, 0x3e9ec9f8bc0c5bd7U, 0xbe7e2b353ea78abfU,
  0x3e4819f2be4f8a8bU, 0x3e60f9da3e12119eU, 0x3df2c5083d7d1260U, 0x3d4b94b0bea59376U,
  0xbe1b51d4bea7d224U, 0xbeaea7bebe6af615U, 0xbe9126d03e28864eU, 0x3c891f10be1bba21U,
  0xbe5f8db03e683216U, 0x3e05faa23d1fd0f0U, 0x3d4666983e6b81b6U, 0x3d9fd8a0bddbb02eU,
  0xbeb1f738be9de729U, 0x3e5d061a3c32d160U, 0xbe8e77543e455be2U, 0xbdb177083db17ec4U,
  0xb7d3ad9e3ea636acU, 0x3e17c4b2bce84821U, 0xbe822c403dfce424U, 0xbdd334383e85032dU,
  0xbe9a85143e75f9daU, 0xbe277d5dbea486aaU, 0x3e83ab62be2d13fbU, 0x3dfa300b3e935914U,
  0xbe8e3101bcc4a7e0U, 0xbde7d6ef3ebb1ae5U, 0x3eb025dd3da01086U, 0x3d9c93dc3c6dceddU,
  0xbe7870903e4a1384U, 0xbe61d09cbd8abe9dU, 0xbe86bdf7bed1600eU, 0xbed33b703ea256a4U,
  0xbdb613483e49ed82U, 0xbe311607be05b3e7U, 0xbd022340be85480eU, 0xbe8d13ad3eaa5d37U,
  0x3dd1dbd03e962a07U, 0x3e2184debea6d628U, 0x3eb02a39be32c2f5U, 0x3e92da31bea0aebbU,
  0x3ea0fdf7be6f19dcU, 0xbe1de1463c66b8a0U, 0xbc0698a0be90c51dU, 0x3e789f263eaf0a0dU,
  0xbe75e8e6be8f4d30U, 0xbdc88d58be3b3bc9U, 0x3e170ef2be12f0d8U, 0xbe9a9f3b3e6946daU,
  0x3e9f57cf3e8e70ddU, 0xbea35df43e9775bcU, 0x3e2be10abd5956b1U, 0x3eab90f1be8a748eU,
  0xbe1913213e81b917U, 0x3cac27d0bdf62babU, 0xbe9f6c46be6607c5U, 0x3e9b9d0cbea2a5abU,
  0xbe09b6383ea8ae05U, 0x3d2471d03e94f4fbU, 0xbe4e62173db03773U, 0x3e9b3d28be5835fdU,
  0xbe52b2e6be3e892eU, 0x3ea5c30fbeb4c5b8U, 0x3d57e3a13de501b6U, 0xbe16d13abe422744U,
  0x3dbeb0b4bd4417b8U, 0xbd4047383e41abdaU, 0xbdb17368bd14a330U, 0x3e27684a3e0db694U,
  0x3ded43e4be92ba00U, 0x3d00e3b83d4ebcb8U, 0xbe8c75d6bd6c69e0U, 0xbc3c04003ea4fe9dU,
  0x3ce131603d24f4b0U, 0x3e00d480bda180ccU, 0x3e62e0cebdb7bd24U, 0xbd8b08c0bc1076c0U,
  0xbe7a0617bea21cfeU, 0xbe53fd463c5faee0U, 0xbda3c8d4bde9c272U, 0xbe95169e3d267c40U,
  0xbc70f4f5bd951ad3U, 0x0U, 0x0U, 0x3d3553cfU,
  0x3c438e58bce85ce7U, 0xbc68921aU, 0xbdf925dcU, 0xbbb32534U,
  0xbebbd7dc3e97edfcU, 0x3e58252e3eb27a17U, 0xbe1f910a3e264f9eU, 0xbe65a4363df51713U,
  0xbbb6e49abf033160U, 0x3dabe3043e14e416U, 0xbe7eaa26be12c01eU, 0xbe7e21f7bd36f880U,
  0xbe00fb40be208e84U, 0xbda44b8c3dfbc5bcU, 0x3e3cf97abea6bfb1U, 0xbdbdab2cbea509eaU,
  0xbe19ab483d607570U, 0xbe70c5a0becbd64eU, 0x3c16f060be8e6224U, 0xbeb231863ea5157bU,
  0x3ebf5fc0be5ffd50U, 0x3e7bf8a23d505168U, 0xbe28a8443e710caaU, 0x3eb28865be54e183U,
  0x3d17f35c3ed3d416U, 0x3ec7e13f3e850eeaU, 0x3e24752e3e63afbcU, 0x3e59af0ebdbe1ec2U,
  0x3e446fe63d29cbc0U, 0x3e4a92463e1f9f76U, 0x3eba77ddbd92d05cU, 0x3d604cb8be4bb5a4U,
  0x3d4cedf8bebbd975U, 0xbe359390bedaf929U, 0x3ed76e91be9019d7U, 0xbe779cc13e7785baU,
  0x3dd47bd8be661c52U, 0x3dae5aacbe8a1a5aU, 0x3ece8fc5bed6e1efU, 0x3e8ce3a53ed389ebU,
  0x3db70d1dbd8f84c0U, 0xbe4214f63ebe5eedU, 0x3e49985e3eaf3481U, 0x3ecc0d95bd214a69U,
  0x3ed8dd943e27ffa2U, 0x3e2a125ebed5db6bU, 0x3e97765b3e9bbbd1U, 0xbe39ce0a3e06fe06U,
  0x3eb884bc3e572455U, 0x3ed47ce53e1166f4U, 0x3ec9d89f3ea8fb6aU, 0x3e69da4ebda8db68U,
  0x3e9449013d23b854U, 0x3e9c317d3e70f10eU, 0x3e5a68f63d403720U, 0x3da6a53c3d87c763U,
  0xbe5d385d3e69c409U, 0xbea75e48bed9db50U, 0xbe43f82dbec1b223U, 0x3e98bf2f3dc5989cU,
  0x3bc88a00bcb6cb15U, 0xbdb0816c3dbf632cU, 0xbebfc97c3dec4214U, 0xbe2145ec3c99bba8U,
  0xbe4e92ecbcd93f16U, 0x3e77259abecd6a5cU, 0x3edc96a9beb61816U, 0xbebe48b9be63ee77U,
  0x3e0b26afbdac870bU, 0xbe94df2abccf2940U, 0xbed6b46d3ebef637U, 0x3e8f501dbf247117U,
  0x3d62d4353da492fbU, 0xbddafbd4be3daa63U, 0x3e328b623e3102b4U, 0x3e8f86f1be21716eU,
  0xbe95efa6be8a6d5aU, 0x3ec4ffdb3cfa0f50U, 0xbe8907d9be5b37b1U, 0x3dff2abcbe1de205U,
  0xbef13a97bee6a180U, 0x3e0a60ee3da438f4U, 0x3eae70cd3ee6073dU, 0xbec18641bd925c0bU,
  0x3ead09fbbe5bd86bU, 0xbce9b290bda46b1cU, 0xbe79e4523d944bdcU, 0x3eb908a7be5b3b35U,
  0x3e9834e7be8c0b8bU, 0xbe0c4c9e3c8d9130U, 0x3ebc5225be5d2653U, 0xbe3a8fb4beb1f602U,
  0xbe47bf45bd0a591dU, 0xbd73c3303e43272aU, 0x3ea9238dbeb7afd7U, 0x3e8e74053e522a98U,
  0xbe2d8ad2bd64ec13U, 0x3ec48019bdecaf2eU, 0x3e94798b3e399081U, 0x3ecb2f87bdc3948aU,
  0x3dc7aa8cbe9a9248U, 0x3bc53340beb3fc2aU, 0x3dd84c14be0f68b6U, 0x3d816b60bed9f160U,
  0xbeb9b9acbea0489cU, 0xbe6e5608be7289d3U, 0x3d5a9200be2f36a0U, 0x3e0816fabece8ab5U,
  0x3e5b01963dbef022U, 0xbeafb9f6be96aa3aU, 0xbe765cd73e64ae82U, 0x3eb2c6fbbd71d025U,
  0x3e93eca0bda13378U, 0x3e8c59153e921d49U, 0x3e89e2bdbefb7899U, 0xbeb20ba23e887cafU,
  0xbd0668983ec5f067U, 0x3ea2e299bd8336ccU, 0x3edc7a293bb27040U, 0xbeda97273d907be7U,
  0xbef2ddccbe82bb9aU, 0xbcba4580be24abbfU, 0xbd1e5e58be8eed49U, 0x3dcfadcc3eb8b61bU,
  0x3d30a6b63e5d1d84U, 0xbe2abf70bc892bd0U, 0x3d8a52a43d9d4b94U, 0x3e89ebd1bdf4c93cU,
  0x3efcbac6bebf9942U, 0x3e89388fbde523d3U, 0x3c4fe9803dfd8664U, 0xbe9a7e8ebdd6916aU,
  0xbd9ab456U, 0xbdbbe5d1U, 0xbc060a1d3d4c88a2U, 0xbc5d85dcbdbb19b7U,
  0xbdf17c99bec1d66dU, 0xbdf233b100000000U, 0xbdab803b00000000U, 0xbdca033bbd7234a5U,
  0xbe99d52e3e548319U, 0x3e599048bd3d979eU, 0x3e12edadbdcb5549U, 0x3f0159013e5ac7f7U,
  0x3ddf1ef13e02978fU, 0xbc698ef63e97fb52U, 0x3f3016983ecf11e8U, 0xbdee2ddf3e7adb77U,
  0x3edb59f23ee58fefU, 0xbe85b92b3f196085U, 0xbe431d243d622c98U, 0x3f001875bf35c221U,
  0xbda1d51bbe86bcccU, 0xbd5f7c893ea84c30U, 0xbfcfd255be5d79daU, 0xbe29d232bef83281U,
  0x3ea41f10bece4f5eU, 0x3d4f4410be61f104U, 0x3ead5f72bd93fb17U, 0x3e3b94a7bf799653U,
  0xbebda983be9afd4fU, 0xbee67b89beb5dfcfU, 0xbf1423f83df72aa8U, 0xbecd42ea3ecc3c70U,
  0xbcbcf6b03f1f7fc4U, 0xbdeb9654bf365b47U, 0xbd4bf206be82dd95U, 0xbe4d5e8b3eadeeb1U,
  0x3f3497863d7b7512U, 0xbdbc50ff3e4df78cU, 0x3df7d199beadccdcU, 0x3f06347cbd9f3847U,
  0x3e5a7c7c3f2fa2afU, 0xbe8b6fc0bf2a2bc1U, 0x3ddfbaabbe9dfa6aU, 0x3dbebda03e74cf18U,
  0x3d7aad76be02b22cU, 0x3ee75792bed22602U, 0xbf2ea79a3ee06ca8U, 0xbe6b1de33e52f775U,
  0x3ea4f908be53b665U, 0xbe6036a8bcd10bf5U, 0xbe699b813e9e3d02U, 0x3dc99fd0bf6a9ac3U,
  0xbe2d863dbf444122U, 0xbebe0649beb6b14eU, 0xc00957823d9bd4f8U, 0x3d8ea080c0178d86U,
  0x3b5c64f03ea7f179U, 0xbe5f0a9f3db1d253U, 0x3df89a52be14aacfU,
};


ai_handle g_embeddedai_weights_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(s_embeddedai_weights_array_u64),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};

